public class Students{
    public static void main(String[] args) throws java.lang.Exception{
        // declare an array in java
        int[] studentsScore = {75, 70, 85, 80, 95};
        // display all the elements in an array 
        // access the elements inside the array using an index number
        for(int i=0; i<studentsScore.length; i++){
            System.out.print(studentsScore[i]+" ");
        }
    }
}